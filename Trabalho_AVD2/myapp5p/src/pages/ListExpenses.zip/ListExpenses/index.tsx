// hooks


import { Header } from '../../components/Header'
import {
  Container,
  Transactions
} from './styles'

import { TransactionExpenses }
  from '../../components/TransactionsExpenses'


export function ListExpenses() {

  return (
    <Container>
      <Header title='Listagem de Gastos' />

      {/* <Transactions> */}
      <TransactionExpenses />
      <TransactionExpenses />
      {/* </Transactions> */}

    </Container>
  )
}
