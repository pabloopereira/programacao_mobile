import {
  Container,
  Description,
  Amount,
  Local,
  Footer,
  Category,
  Date,
} from "./styles";


export function TransactionExpenses() {
  return (
    <Container>
      <Description>Pizza</Description>
      <Amount>R$ 50.00</Amount>
      <Local>Pizza Tutto</Local>

      <Footer>
        <Category>Alimentacao</Category>
        <Date>07/06/2024</Date>
      </Footer>

    </Container>
  )
}