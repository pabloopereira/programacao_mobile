import { NfStorageDTO } from "../handleNf/NfStorageDTO";

export const codigosImposto = [
  { label: "1234", value: "1234" },
  { label: "6789", value: "6789" },
  { label: "1708", value: "1708" },
  { label: "5952", value: "5952" },
];

export const estados = [
  { label: "RJ", value: "RJ" },
  { label: "SP", value: "SP" },
  { label: "MG", value: "MG" },
];

export const fornecedores = [
  { label: "Totvs", value: "Totvs" },
  { label: "Microsoft", value: "Microsoft" },
];

export const numberToBRL = (currency: number) => {
  const formattedCurrency = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(currency);

  return formattedCurrency.replace(/\s/g, "");
};

export const brlToNumber = (brlString: string) => {
  const cleanedString = brlString.replace(/[R$\s]/g, "").trim();
  const numberString = cleanedString.replace(/\./g, "").replace(/,/g, ".");

  const number = parseFloat(numberString);

  if (isNaN(number)) {
    throw new Error(`Invalid BRL format: ${brlString}`);
  }

  return number;
};

export const calcularImposto = (data: NfStorageDTO): number => {
  switch (data.estado) {
    case "RJ":
      return calcularImpostoRJ(data);
    case "SP":
      return calcularImpostoSP(data);
    case "MG":
      return calcularImpostoMG(data);
    default:
      return 0;
  }
};

const taxaImpostoRJ = 0.01;
const taxaImpostoSP = 0.02;
const taxaImpostoMG = 0.03;

const temImposto = (codigoImposto: string): boolean => {
  return codigoImposto === "1234" || codigoImposto === "6789";
};

const calcularImpostoRJ = (data: NfStorageDTO): number => {
  return temImposto(data.codigoImposto)
    ? brlToNumber(data.valorNotaFiscal) * taxaImpostoRJ
    : 0;
};

const calcularImpostoSP = (data: NfStorageDTO): number => {
  return temImposto(data.codigoImposto)
    ? brlToNumber(data.valorNotaFiscal) * taxaImpostoSP
    : 0;
};

const calcularImpostoMG = (data: NfStorageDTO): number => {
  return temImposto(data.codigoImposto)
    ? brlToNumber(data.valorNotaFiscal) * taxaImpostoMG
    : 0;
};
