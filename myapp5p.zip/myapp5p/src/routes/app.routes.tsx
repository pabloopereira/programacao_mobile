import { MaterialIcons } from "@expo/vector-icons";
import {
  BottomTabNavigationProp,
  createBottomTabNavigator,
} from "@react-navigation/bottom-tabs";
import { useTheme } from "styled-components";
import { Cadastro } from "../pages/Cadastro";
import { CategoriasNf } from "../pages/CategoriasNf";
import { ListNfs } from "../pages/ListNfs";

type AppRoutes = {
  cadastro: undefined;
  list: undefined;
  resume: undefined;
};

export type AppNavigationRoutesProp = BottomTabNavigationProp<AppRoutes>;

const { Navigator, Screen } = createBottomTabNavigator<AppRoutes>();

export function AppRoutes() {
  const theme = useTheme();

  return (
    <Navigator
      screenOptions={{
        headerShown: false,
        tabBarLabelPosition: "beside-icon",
        tabBarActiveTintColor: theme.colors.secondary,
        tabBarInactiveTintColor: theme.colors.text,
        tabBarStyle: {
          height: 88,
        },
      }}
    >
      <Screen
        name="cadastro"
        component={Cadastro}
        options={{
          tabBarLabel: "Cadastro",
          tabBarIcon: ({ size, color }) => (
            <MaterialIcons name="add" size={size} color={color} />
          ),
        }}
      />

      <Screen
        name="list"
        component={ListNfs}
        options={{
          tabBarLabel: "Listagem",
          tabBarIcon: ({ size, color }) => (
            <MaterialIcons name="list" size={size} color={color} />
          ),
        }}
      />

      <Screen
        name="resume"
        component={CategoriasNf}
        options={{
          tabBarLabel: "Resumo",
          tabBarIcon: ({ size, color }) => (
            <MaterialIcons name="search" size={size} color={color} />
          ),
        }}
      />
    </Navigator>
  );
}
