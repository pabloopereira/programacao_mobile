import AsyncStorage from "@react-native-async-storage/async-storage";
import { Alert } from "react-native";
import { NF_COLLECTION } from "../storage/storageConfig";
import { nfGetAll } from "./nfGetAll";

export async function nfDelete(id: string) {
  try {
    const storageNf = await nfGetAll();

    const nfs = storageNf.filter((nf) => nf.id !== id);

    await AsyncStorage.setItem(NF_COLLECTION, JSON.stringify(nfs));
  } catch (error) {
    Alert.alert("Atenção", "Não foi possível excluir nota fiscal!");
    throw error;
  }
}
