export type NfStorageDTO = {
  id: string;
  notaFiscal: string;
  codigoImposto: string;
  valorNotaFiscal: string;
  valorImposto?: string;
  estado: string;
  fornecedor: string;
};
