import AsyncStorage from "@react-native-async-storage/async-storage";
import { Alert } from "react-native";
import { NF_COLLECTION } from "../storage/storageConfig";
import { calcularImposto, numberToBRL } from "../utils/utils";
import { NfStorageDTO } from "./NfStorageDTO";
import { nfGetAll } from "./nfGetAll";

export async function nfCreate(newNf: NfStorageDTO) {
  try {
    const valorImposto = calcularImposto(newNf);
    newNf.valorImposto = numberToBRL(valorImposto);
    const storageNf = await nfGetAll();

    const storage = [...storageNf, newNf];

    await AsyncStorage.setItem(NF_COLLECTION, JSON.stringify(storage));
  } catch (error) {
    Alert.alert("Atenção", "Não foi possível fazer gravação!");
    throw error;
  }
}
