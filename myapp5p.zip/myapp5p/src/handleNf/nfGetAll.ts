import AsyncStorage from "@react-native-async-storage/async-storage";
import { Alert } from "react-native";
import { NF_COLLECTION } from "../storage/storageConfig";
import { NfStorageDTO } from "./NfStorageDTO";

export async function nfGetAll() {
  try {
    const storage = await AsyncStorage.getItem(NF_COLLECTION);

    const nfs: NfStorageDTO[] = storage ? JSON.parse(storage) : [];

    return nfs;
  } catch (error) {
    Alert.alert("Atenção", "Não foi possível fazer a leitura dos dados!");
    throw error;
  }
}
