import { useFocusEffect } from "@react-navigation/native";
import { useCallback, useState } from "react";
import { Alert, FlatList } from "react-native";
import { Header } from "../../components/Header";
import { NfStorageDTO } from "../../handleNf/NfStorageDTO";
import { nfGetAll } from "../../handleNf/nfGetAll";
import {
  brlToNumber,
  estados,
  fornecedores,
  numberToBRL,
} from "../../utils/utils";
import { Amount, Container, Description, Transactions } from "./styles";

export function CategoriasNf() {
  const [nfs, setNfs] = useState<NfStorageDTO[]>([]);

  const combinations = fornecedores.flatMap((item1) =>
    estados.map((item2) => ({ item1, item2 }))
  );

  async function loadNfs() {
    try {
      const data = await nfGetAll();
      setNfs(data);
    } catch (error) {
      Alert.alert("Erro", "Não foi possível ler os dados gravados!");
    }
  }

  useFocusEffect(
    useCallback(() => {
      loadNfs();
    }, [])
  );

  function contarOcorrencias(fornecedor: string, estado: string): number {
    return nfs.filter(
      (nf) => nf.fornecedor === fornecedor && nf.estado === estado
    ).length;
  }

  function calcularValorTotalNotaFiscal(
    fornecedor: string,
    estado: string
  ): string {
    const nfsCorrespondentes = nfs.filter(
      (nf) => nf.fornecedor === fornecedor && nf.estado === estado
    );
    const valor = nfsCorrespondentes
      .map((nf) => {
        return {
          vi: brlToNumber(nf.valorNotaFiscal),
          vo: brlToNumber(nf.valorImposto!),
        };
      })
      .reduce((total, nf) => {
        return total + nf.vi + nf.vo;
      }, 0);

    return numberToBRL(valor);
  }

  return (
    <Container>
      <Header title="Resumo Notas Fiscais" />

      <FlatList
        data={combinations}
        keyExtractor={(item, index) => `${item.item1}-${item.item2}-${index}`}
        renderItem={({ item }) => (
          <Transactions>
            <Container>
              <Description>{`${item.item1.value}/${item.item2.value}`}</Description>
              <Description>
                {contarOcorrencias(item.item1.value, item.item2.value)}{" "}
                ocorrência(s)
              </Description>
              <Amount>
                Valor:{" "}
                {calcularValorTotalNotaFiscal(
                  item.item1.value,
                  item.item2.value
                )}
              </Amount>
            </Container>
          </Transactions>
        )}
        showsVerticalScrollIndicator={false}
      />
    </Container>
  );
}
