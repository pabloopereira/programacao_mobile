import { Button } from "../../components/Button";
import { NfStorageDTO } from "../../handleNf/NfStorageDTO";
import { Amount, Container, Description } from "./styles";

type PropsData = {
  data: NfStorageDTO;
  onRemove: () => void;
};

export function Nf({ data, onRemove }: PropsData) {
  return (
    <Container>
      <Description>NF: {data.notaFiscal}</Description>
      <Description>Cod: {data.codigoImposto}</Description>
      <Amount>Valor NF: {data.valorNotaFiscal}</Amount>
      <Amount>Imposto: {data.valorImposto}</Amount>
      <Description>UF: {data.estado}</Description>
      <Description>Fornecedor: {data.fornecedor}</Description>

      <Button title="Excluir" onPress={onRemove} />
    </Container>
  );
}
