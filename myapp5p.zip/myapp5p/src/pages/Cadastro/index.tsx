import { useState } from "react";
import { Alert } from "react-native";
import { Button } from "../../components/Button";
import { Header } from "../../components/Header";
import { Input } from "../../components/Input";
import { InputAmount } from "../../components/InputAmount";
import { InputSelect } from "../../components/InputSelect";
import { NfStorageDTO } from "../../handleNf/NfStorageDTO";
import { nfCreate } from "../../handleNf/nfCreate";
import { codigosImposto, estados, fornecedores } from "../../utils/utils";
import { Container } from "./styles";

export function Cadastro() {
  const [notaFiscal, setNotaFiscal] = useState("");
  const [codigoImposto, setCodigoImposto] = useState("1234");
  const [valorNotaFiscal, setValorNotaFiscal] = useState("R$0,00");
  const [estado, setEstado] = useState("RJ");
  const [fornecedor, setFornecedor] = useState("Totvs");

  async function handleAddNewNf() {
    // await AsyncStorage.clear();
    if (notaFiscal.trim() === "") {
      return Alert.alert(
        "Usuário",
        "Por favor, insira um nome válido para a NF"
      );
    }

    if (valorNotaFiscal.trim() === "R$0,00") {
      return Alert.alert(
        "Usuário",
        "Por favor, insira um valor válido para a NF"
      );
    }

    const data: NfStorageDTO = {
      id: String(new Date().getTime()),
      notaFiscal: notaFiscal,
      codigoImposto: codigoImposto,
      valorNotaFiscal: valorNotaFiscal,
      estado: estado,
      fornecedor: fornecedor,
    };

    setNotaFiscal("");
    setValorNotaFiscal("R$0,00");

    await nfCreate(data);
  }

  return (
    <Container>
      <Header title="Cadastro de Notas Fiscais" />

      <Input
        placeholder="Nota Fiscal"
        placeholderTextColor="#6B6B6B"
        autoCapitalize="words"
        value={notaFiscal}
        onChangeText={(value) => setNotaFiscal(value)}
      />

      <InputSelect
        fieldName="Código do Imposto"
        selectedValue={codigoImposto}
        onValueChange={(itemValue, itemIndex) => setCodigoImposto(itemValue)}
        items={codigosImposto}
      />

      <InputAmount
        placeholder="Valor da Nota Fiscal"
        placeholderTextColor="#6B6B6B"
        value={valorNotaFiscal}
        onChangeText={(value) => setValorNotaFiscal(value)}
      />

      <InputSelect
        fieldName="Estado"
        selectedValue={estado}
        onValueChange={(itemValue, itemIndex) => setEstado(itemValue)}
        items={estados}
      />

      <InputSelect
        fieldName="Fornecedor"
        selectedValue={fornecedor}
        onValueChange={(itemValue, itemIndex) => setFornecedor(itemValue)}
        items={fornecedores}
      />

      <Button title="Adicionar" onPress={handleAddNewNf} />
    </Container>
  );
}
