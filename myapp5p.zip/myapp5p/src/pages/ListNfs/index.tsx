import { useFocusEffect } from "@react-navigation/native";
import { useCallback, useState } from "react";
import { Alert, FlatList } from "react-native";
import { Header } from "../../components/Header";
import { NfStorageDTO } from "../../handleNf/NfStorageDTO";
import { nfDelete } from "../../handleNf/nfDelete";
import { nfGetAll } from "../../handleNf/nfGetAll";
import { Nf } from "../Nf";
import { Container } from "./styles";

export function ListNfs() {
  const [nfs, setNfs] = useState<NfStorageDTO[]>([]);

  async function loadNfs() {
    try {
      const data = await nfGetAll();
      setNfs(data);
    } catch (error) {
      Alert.alert("Erro", "Não foi possível ler os dados gravados!");
    }
  }

  async function handleRemoveNf(id: string) {
    Alert.alert("Remover", "Remover Nota Fiscal?", [
      {
        text: "Sim",
        onPress: async () => {
          await nfDelete(id).then(async () => setNfs(await nfGetAll()));
        },
      },
      {
        text: "Não",
        style: "cancel",
      },
    ]);
  }

  useFocusEffect(
    useCallback(() => {
      loadNfs();
    }, [])
  );

  return (
    <Container>
      <Header title="Listagem de Notas Fiscais" />

      <FlatList
        data={nfs}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Nf data={item} onRemove={() => handleRemoveNf(item.id)} />
        )}
        showsVerticalScrollIndicator={false}
      />
    </Container>
  );
}
