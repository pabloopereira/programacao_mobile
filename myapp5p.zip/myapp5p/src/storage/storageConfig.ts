const NF_COLLECTION = "@myapp5:nf";

export { NF_COLLECTION };
