import {
  Picker,
  PickerItemProps,
  PickerProps,
} from "@react-native-picker/picker";
import { Text } from "react-native";
import { Container, InputStyle } from "./styles";

type FieldDescriptionProps = {
  fieldName: string;
};

type InputProps = FieldDescriptionProps &
  PickerProps<string> & {
    items: Array<PickerItemProps>;
  };

export function InputSelect({
  fieldName,
  selectedValue,
  onValueChange,
  items,
  ...rest
}: InputProps) {
  return (
    <Container>
      <Text>{fieldName}</Text>
      <InputStyle
        selectedValue={selectedValue}
        onValueChange={onValueChange}
        {...rest}
      >
        {items.map((item, index) => (
          <Picker.Item key={index} {...item} />
        ))}
      </InputStyle>
    </Container>
  );
}
